#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include "calc.hpp"

std::vector<Calc::Token> Calc::infixToPostfix(const std::vector<Token>& input) {
  std::vector<Token> output {};
  // To store the operators
  std::vector<Token> operatorStack {};

  for (Token t : input) {
    if (t.type == 'n') { // Token is a number
      output.push_back(t);
    } else if (t.type == '(') { // Token is an open bracket operator
      operatorStack.push_back(t);
    } else if (t.type == ')') { // Token is a closed bracket operator
      // Operators inside brackets have precedence so starting at the end of
      // operatorStack, move each operator to output until an open bracket is
      // encountered
      for (int i = operatorStack.size() - 1; operatorStack[i].type != '('; --i) {
        output.push_back(operatorStack[i]);
        operatorStack.pop_back();
      }
      // Remove the open bracket
      operatorStack.pop_back();
    } else { // Token is '+', '-', '*' or '/' operator
      if (!operatorStack.empty()) {
        // Get the operator at the top of operatorStack
        Token top = operatorStack.back();
        // If top is not an open bracket and has >= precedence to t, move it to
        // output
        if (top.type != '(') {
          if ((top.type == '*' || top.type == '/') && // Top has greater precedence
                (t.type == '+' || t.type == '-')) {
            output.push_back(top);
            operatorStack.pop_back();
          }
          if (((top.type == '*' || top.type == '/') && // Top has equal precedence
                 (t.type == '*' || t.type == '/')) ||
              ((top.type == '+' || top.type == '-') &&
                 (t.type == '+' || t.type == '-'))) {
            output.push_back(top);
            operatorStack.pop_back();
          }
        }
      }
      // Append t to operatorStack
      operatorStack.push_back(t);
    }
  }

  // Reverse operatorStack
  std::reverse(operatorStack.begin(), operatorStack.end());
  // Append operatorStack to output
  output.insert(output.end(), operatorStack.begin(), operatorStack.end());

  return output;
}

int Calc::evalPostfix(const std::vector<Token>& tokens) {
  if (tokens.empty()) {
    return 0;
  }
  std::vector<int> stack;
  for (Token t : tokens) {
    if (t.type == 'n') {
      stack.push_back(t.val);
    } else {
      int val = 0;
      if (t.type == '+') {
        val = stack.back() + *(stack.end()-2);
      } else if (t.type == '*') {
        val = stack.back() * *(stack.end()-2);
      } else if (t.type == '-') {
        val = *(stack.end()-2) - stack.back();
      } else if (t.type == '/') {
        if (stack.back() == 0) {
          throw std::runtime_error("divide by zero");
        }
        val = *(stack.end()-2) / stack.back();
      } else {
          std::cout << "invalid token\n";
      }
      stack.pop_back();
      stack.pop_back();
      stack.push_back(val);
    }
  }
  return stack.back();
}

std::vector<Calc::Token> Calc::tokenise(const std::string& expression) {
  const std::vector<char> symbols = {'+', '-', '*', '/', '(', ')'};
  std::vector<Token> tokens {};
  for (std::size_t i =0; i < expression.size(); ++i) {
    const char c = expression[i];
    // check if c is one of '+', '-', '*', '/', '(', ')'
    if (std::find(symbols.begin(), symbols.end(), c) != symbols.end()) {
      tokens.push_back({c});
    } else if (isdigit(c)) {
      // process multiple digit integers
      std::string num {c};
      while (i + 1 < expression.size() && isdigit(expression[i + 1])) {
        ++i;
        num.push_back(expression[i]);
      }
      tokens.push_back({'n', std::stoi(num)});
    }
  }
  return tokens;
}

int Calc::eval(const std::string& expression) {
  std::vector<Token> tokens = tokenise(expression);
  std::vector<Token> postfix = infixToPostfix(tokens);
  return evalPostfix(postfix);
}
